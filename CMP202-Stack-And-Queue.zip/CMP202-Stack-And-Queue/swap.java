public class swap {

    public static void main (String[]args){
        int number = 78;
        int anothernumber = 32;

        int temp = number;
        number = anothernumber;
        anothernumber = temp;
    }
}
